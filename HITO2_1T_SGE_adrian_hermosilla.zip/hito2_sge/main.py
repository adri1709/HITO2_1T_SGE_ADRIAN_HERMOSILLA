import tkinter as tk
from tkinter import messagebox, simpledialog
from tkinter import ttk
import mysql.connector
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd
import ttkbootstrap as tb
from ttkbootstrap.dialogs import Messagebox, Querybox

class EncuestaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Encuestas Médicas")
        self.root.configure(bg="#ffebcd")  # Pastel background color

        # Conexión a la base de datos
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="curso",
            database="ENCUESTAS"
        )
        self.cursor = self.conn.cursor()

        # Crear el Notebook
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(expand=True, fill='both')

        # Crear las pestañas
        self.encuestas_frame = ttk.Frame(self.notebook)
        self.graficos_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.encuestas_frame, text='Encuestas')
        self.notebook.add(self.graficos_frame, text='Gráficos')

        # Crear la interfaz de encuestas
        self.create_encuestas_widgets()

        # Crear la interfaz de gráficos
        self.create_graficos_widgets()

    def create_encuestas_widgets(self):
        style = ttk.Style()
        style.configure("TLabel", background="#ffebcd", foreground="#d32f2f", font=("Arial", 12, "bold"))  # Red text
        style.configure("TEntry", background="#ffffff", foreground="#d32f2f", font=("Arial", 12))  # Red text
        style.configure("TButton", background="#ffcccb", foreground="#d32f2f",
                        font=("Arial", 12, "bold"))  # Light red button with red text

        fields = [
            ("Edad", "edad_entry"), ("Sexo", "sexo_entry"), ("Bebidas por Semana", "bebidas_semana_entry"),
            ("Cervezas por Semana", "cervezas_semana_entry"), ("Bebidas Fin de Semana", "bebidas_fin_semana_entry"),
            ("Bebidas Destiladas por Semana", "bebidas_destiladas_semana_entry"),
            ("Vinos por Semana", "vinos_semana_entry"),
            ("Pérdidas de Control", "perdidas_control_entry"),
            ("Diversión Dependencia Alcohol", "diversion_dependencia_alcohol_entry")
        ]

        for i, (label_text, entry_attr) in enumerate(fields):
            ttk.Label(self.encuestas_frame, text=label_text + ":").grid(row=i, column=0, padx=10, pady=5, sticky="e")
            setattr(self, entry_attr, ttk.Entry(self.encuestas_frame))
            getattr(self, entry_attr).grid(row=i, column=1, padx=10, pady=5, sticky="w")

        # Define the hidden fields
        self.problemas_digestivos_entry = ttk.Entry(self.encuestas_frame)
        self.tension_alta_entry = ttk.Entry(self.encuestas_frame)
        self.dolor_cabeza_entry = ttk.Entry(self.encuestas_frame)

        ttk.Button(self.encuestas_frame, text="Agregar", command=self.agregar_dato).grid(row=len(fields), column=0,
                                                                                         padx=10, pady=10)
        ttk.Button(self.encuestas_frame, text="Mostrar", command=self.mostrar_datos).grid(row=len(fields), column=1,
                                                                                          padx=10, pady=10)
        ttk.Button(self.encuestas_frame, text="Actualizar", command=self.actualizar_dato).grid(row=len(fields) + 1,
                                                                                               column=0, padx=10,
                                                                                               pady=10)
        ttk.Button(self.encuestas_frame, text="Eliminar", command=self.eliminar_dato).grid(row=len(fields) + 1,
                                                                                           column=1, padx=10, pady=10)

        # Dropdown for sorting
        self.sort_by = tk.StringVar()
        self.sort_by.set("Seleccione campo")
        sort_options = [
            "Edad", "Sexo", "Bebidas por Semana", "Cervezas por Semana", "Bebidas Fin de Semana",
            "Bebidas Destiladas por Semana", "Vinos por Semana", "Pérdidas de Control",
            "Diversión Dependencia Alcohol", "Problemas Digestivos", "Tensión Alta", "Dolor de Cabeza"
        ]
        ttk.Label(self.encuestas_frame, text="Ordenar por:").grid(row=len(fields) + 2, column=0, padx=10, pady=10)
        ttk.OptionMenu(self.encuestas_frame, self.sort_by, *sort_options).grid(row=len(fields) + 2, column=1, padx=10,
                                                                               pady=10)
        ttk.Button(self.encuestas_frame, text="Ordenar", command=self.ordenar_datos).grid(row=len(fields) + 3, column=0,
                                                                                          columnspan=2, padx=10,
                                                                                          pady=10)

        # Button to export data
        ttk.Button(self.encuestas_frame, text="Exportar a Excel", command=self.exportar_datos).grid(row=len(fields) + 6,
                                                                                                    column=0,
                                                                                                    columnspan=2,
                                                                                                    padx=10, pady=10)

    def agregar_dato(self):
        data = {
            "edad": self.edad_entry.get(),
            "sexo": self.sexo_entry.get(),
            "bebidas_semana": self.bebidas_semana_entry.get(),
            "cervezas_semana": self.cervezas_semana_entry.get(),
            "bebidas_fin_semana": self.bebidas_fin_semana_entry.get(),
            "bebidas_destiladas_semana": self.bebidas_destiladas_semana_entry.get(),
            "vinos_semana": self.vinos_semana_entry.get(),
            "perdidas_control": self.perdidas_control_entry.get(),
            "diversion_dependencia_alcohol": self.diversion_dependencia_alcohol_entry.get(),
            "problemas_digestivos": self.problemas_digestivos_entry.get(),
            "tension_alta": self.tension_alta_entry.get(),
            "dolor_cabeza": self.dolor_cabeza_entry.get()
        }

        if all(data.values()):
            self.cursor.execute(
                "INSERT INTO ENCUESTA (edad, Sexo, BebidasSemana, CervezasSemana, BebidasFinSemana, BebidasDestiladasSemana, VinosSemana, PerdidasControl, DiversionDependenciaAlcohol, ProblemasDigestivos, TensionAlta, DolorCabeza) VALUES (%(edad)s, %(sexo)s, %(bebidas_semana)s, %(cervezas_semana)s, %(bebidas_fin_semana)s, %(bebidas_destiladas_semana)s, %(vinos_semana)s, %(perdidas_control)s, %(diversion_dependencia_alcohol)s, %(problemas_digestivos)s, %(tension_alta)s, %(dolor_cabeza)s)",
                data
            )
            self.conn.commit()
            Messagebox.show_info("Éxito", "Dato agregado correctamente", parent=self.root)
        else:
            Messagebox.show_warning("Advertencia", "Todos los campos son obligatorios", parent=self.root)

    def ordenar_datos(self):
        # Obtener el campo seleccionado
        sort_field = self.sort_by.get()
        if sort_field == "Seleccione campo":
            Messagebox.show_warning("Advertencia", "Seleccione un campo para ordenar o filtrar", parent=self.root)
            return

        # Opciones de filtro específicas
        if sort_field == "Alta frecuencia de consumo de alcohol":
            query = "SELECT * FROM ENCUESTA WHERE BebidasSemana > 10"
        elif sort_field == "Perdidas de control > 3":
            query = "SELECT * FROM ENCUESTA WHERE PerdidasControl > 3"
        elif sort_field == "Dolor de cabeza y Tensión alta":
            query = "SELECT * FROM ENCUESTA WHERE DolorCabeza = 1 AND TensionAlta = 1"
        else:
            # Mapeo del campo para la base de datos
            field_map = {
                "Edad": "edad",
                "Sexo": "Sexo",
                "Bebidas por Semana": "BebidasSemana",
                "Cervezas por Semana": "CervezasSemana",
                "Bebidas Fin de Semana": "BebidasFinSemana",
                "Bebidas Destiladas por Semana": "BebidasDestiladasSemana",
                "Vinos por Semana": "VinosSemana",
                "Pérdidas de Control": "PerdidasControl",
                "Diversión Dependencia Alcohol": "DiversionDependenciaAlcohol",
                "Problemas Digestivos": "ProblemasDigestivos",
                "Tensión Alta": "TensionAlta",
                "Dolor de Cabeza": "DolorCabeza"
            }
            sort_field_db = field_map[sort_field]
            query = f"SELECT * FROM ENCUESTA ORDER BY {sort_field_db}"

        # Ejecutar la consulta y mostrar resultados
        self.cursor.execute(query)
        rows = self.cursor.fetchall()

        if not rows:
            Messagebox.show_info("Información", "No se encontraron datos para mostrar", parent=self.root)
            return

        # Limpiar el Treeview existente
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Insertar datos en el Treeview
        for row in rows:
            self.tree.insert('', 'end', values=row)

    def mostrar_datos(self):
        if not hasattr(self, "tree"):
            self.data_frame = ttk.Frame(self.encuestas_frame)
            self.data_frame.grid(row=0, column=2, rowspan=20, padx=10, pady=10, sticky="nsew")

            self.tree = ttk.Treeview(self.data_frame, show="headings")
            self.tree.pack(side="left", fill="both", expand=True)

            self.scrollbar = ttk.Scrollbar(self.data_frame, orient="vertical", command=self.tree.yview)
            self.scrollbar.pack(side="right", fill="y")
            self.tree.configure(yscroll=self.scrollbar.set)

            self.tree.bind("<ButtonRelease-1>", self.on_tree_select)

        self.cursor.execute("SELECT * FROM ENCUESTA")
        rows = self.cursor.fetchall()
        columns = [desc[0] for desc in self.cursor.description]

        if not self.tree["columns"]:
            self.tree["columns"] = columns
            for col in columns:
                self.tree.heading(col, text=col, command=lambda c=col: self.ordenar_datos(c, "ASC"))
                self.tree.column(col, width=100)

        for item in self.tree.get_children():
            self.tree.delete(item)

        for row in rows:
            self.tree.insert("", "end", values=row)

    def on_tree_select(self, event):
        selected_item = self.tree.selection()[0]
        values = self.tree.item(selected_item, "values")

        self.edad_entry.delete(0, tk.END)
        self.edad_entry.insert(0, values[1])
        self.sexo_entry.delete(0, tk.END)
        self.sexo_entry.insert(0, values[2])
        self.bebidas_semana_entry.delete(0, tk.END)
        self.bebidas_semana_entry.insert(0, values[3])
        self.cervezas_semana_entry.delete(0, tk.END)
        self.cervezas_semana_entry.insert(0, values[4])
        self.bebidas_fin_semana_entry.delete(0, tk.END)
        self.bebidas_fin_semana_entry.insert(0, values[5])
        self.bebidas_destiladas_semana_entry.delete(0, tk.END)
        self.bebidas_destiladas_semana_entry.insert(0, values[6])
        self.vinos_semana_entry.delete(0, tk.END)
        self.vinos_semana_entry.insert(0, values[7])
        self.perdidas_control_entry.delete(0, tk.END)
        self.perdidas_control_entry.insert(0, values[8])
        self.diversion_dependencia_alcohol_entry.delete(0, tk.END)
        self.diversion_dependencia_alcohol_entry.insert(0, values[9])
        self.problemas_digestivos_entry.delete(0, tk.END)
        self.problemas_digestivos_entry.insert(0, values[10])
        self.tension_alta_entry.delete(0, tk.END)
        self.tension_alta_entry.insert(0, values[11])
        self.dolor_cabeza_entry.delete(0, tk.END)
        self.dolor_cabeza_entry.insert(0, values[12])

    def actualizar_dato(self):
        id_encuesta = self.get_id_encuesta()
        if not id_encuesta:
            return

        data = {
            "edad": self.edad_entry.get(),
            "sexo": self.sexo_entry.get(),
            "bebidas_semana": self.bebidas_semana_entry.get(),
            "cervezas_semana": self.cervezas_semana_entry.get(),
            "bebidas_fin_semana": self.bebidas_fin_semana_entry.get(),
            "bebidas_destiladas_semana": self.bebidas_destiladas_semana_entry.get(),
            "vinos_semana": self.vinos_semana_entry.get(),
            "perdidas_control": self.perdidas_control_entry.get(),
            "diversion_dependencia_alcohol": self.diversion_dependencia_alcohol_entry.get(),
            "problemas_digestivos": self.problemas_digestivos_entry.get(),
            "tension_alta": self.tension_alta_entry.get(),
            "dolor_cabeza": self.dolor_cabeza_entry.get()
        }

        if all(data.values()):
            self.cursor.execute(
                "UPDATE ENCUESTA SET edad=%(edad)s, Sexo=%(sexo)s, BebidasSemana=%(bebidas_semana)s, CervezasSemana=%(cervezas_semana)s, BebidasFinSemana=%(bebidas_fin_semana)s, BebidasDestiladasSemana=%(bebidas_destiladas_semana)s, VinosSemana=%(vinos_semana)s, PerdidasControl=%(perdidas_control)s, DiversionDependenciaAlcohol=%(diversion_dependencia_alcohol)s, ProblemasDigestivos=%(problemas_digestivos)s, TensionAlta=%(tension_alta)s, DolorCabeza=%(dolor_cabeza)s WHERE idEncuesta=%(id_encuesta)s",
                {**data, "id_encuesta": id_encuesta}
            )
            self.conn.commit()
            Messagebox.show_info("Éxito", "Dato actualizado correctamente", parent=self.root)
        else:
            Messagebox.show_warning("Advertencia", "Todos los campos son obligatorios", parent=self.root)

    def eliminar_dato(self):
        id_encuesta = self.get_id_encuesta()
        if not id_encuesta:
            return

        self.cursor.execute("DELETE FROM ENCUESTA WHERE idEncuesta=%s", (id_encuesta,))
        self.conn.commit()
        Messagebox.show_info("Éxito", "Dato eliminado correctamente", parent=self.root)

    def create_graficos_widgets(self):
        ttk.Label(self.graficos_frame, text="Seleccione campo para graficar:").grid(row=0, column=0, padx=10, pady=10)

        # Inicializar con 'Seleccione'
        self.grafico_sort_by = tk.StringVar()
        self.grafico_sort_by.set("Seleccione")
        sort_options = ["Seleccione", "Edad", "Sexo", "Bebidas por Semana", "Cervezas por Semana",
                        "Bebidas Fin de Semana", "Bebidas Destiladas por Semana", "Vinos por Semana",
                        "Pérdidas de Control", "Diversión Dependencia Alcohol", "Problemas Digestivos",
                        "Tensión Alta", "Dolor de Cabeza"]
        ttk.OptionMenu(self.graficos_frame, self.grafico_sort_by, *sort_options).grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self.graficos_frame, text="Seleccione tipo de gráfico:").grid(row=1, column=0, padx=10, pady=10)

        # Inicializar con 'Seleccione'
        self.grafico_tipo = tk.StringVar()
        self.grafico_tipo.set("Seleccione")
        tipo_options = ["Seleccione", "Barras", "Líneas"]
        ttk.OptionMenu(self.graficos_frame, self.grafico_tipo, *tipo_options).grid(row=1, column=1, padx=10, pady=10)

        ttk.Button(self.graficos_frame, text="Graficar", command=self.graficar_datos).grid(row=2, column=0,
                                                                                           columnspan=2, padx=10,
                                                                                           pady=10)

    def graficar_datos(self):
        sort_field = self.grafico_sort_by.get()
        if not sort_field:
            Messagebox.show_warning("Advertencia", "Seleccione un campo para graficar", parent=self.root)
            return

        field_map = {
            "Edad": "edad",
            "Sexo": "Sexo",
            "Bebidas por Semana": "BebidasSemana",
            "Cervezas por Semana": "CervezasSemana",
            "Bebidas Fin de Semana": "BebidasFinSemana",
            "Bebidas Destiladas por Semana": "BebidasDestiladasSemana",
            "Vinos por Semana": "VinosSemana",
            "Pérdidas de Control": "PerdidasControl",
            "Diversión Dependencia Alcohol": "DiversionDependenciaAlcohol",
            "Problemas Digestivos": "ProblemasDigestivos",
            "Tensión Alta": "TensionAlta",
            "Dolor de Cabeza": "DolorCabeza"
        }
        sort_field_db = field_map[sort_field]

        self.cursor.execute(f"SELECT edad, {sort_field_db} FROM ENCUESTA ORDER BY {sort_field_db}")
        rows = self.cursor.fetchall()

        if not rows:
            Messagebox.show_info("Información", "No se encontraron resultados para graficar", parent=self.root)
            return

        df = pd.DataFrame(rows, columns=["Edad", "Valor"])

        fig, ax = plt.subplots()
        chart_type = self.grafico_tipo.get()
        if chart_type == "Barras":
            ax.bar(df["Edad"], df["Valor"], color='blue')
        elif chart_type == "Líneas":
            ax.plot(df["Edad"], df["Valor"], marker='o', linestyle='-', color='blue')

        ax.set_title(f"Datos ordenados por {sort_field}")
        ax.set_xlabel("Edad")
        ax.set_ylabel(sort_field)

        canvas = FigureCanvasTkAgg(fig, master=self.graficos_frame)
        canvas.draw()
        canvas.get_tk_widget().grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")


    def exportar_datos(self):
        try:
            self.cursor.execute("SELECT * FROM ENCUESTA")
            rows = self.cursor.fetchall()
            if rows:
                df = pd.DataFrame(rows, columns=[desc[0] for desc in self.cursor.description])
                file_path = Querybox.get_string("Guardar como", "Ingrese el nombre del archivo (sin extensión):", parent=self.root)
                if file_path:
                    df.to_excel(f"{file_path}.xlsx", index=False)
                    Messagebox.show_info("Éxito", f"Datos exportados a {file_path}.xlsx", parent=self.root)
        except Exception as e:
            Messagebox.show_error("Error", f"Error al exportar datos: {e}", parent=self.root)

    def get_id_encuesta(self):
        id_encuesta = Querybox.get_string("ID Encuesta", "Ingrese el ID de la encuesta:", parent=self.root)
        if not id_encuesta:
            Messagebox.show_warning("Advertencia", "El ID de la encuesta es obligatorio", parent=self.root)
            return None
        return id_encuesta

if __name__ == "__main__":
    root = tb.Window(themename="darkly")
    app = EncuestaApp(root)
    root.mainloop()